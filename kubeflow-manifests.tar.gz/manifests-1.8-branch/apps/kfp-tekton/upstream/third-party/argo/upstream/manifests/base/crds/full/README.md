# Full CRDs

These CRDs have full schema validation. As a result, they are large and probably not suitable to be used in your cluster.
